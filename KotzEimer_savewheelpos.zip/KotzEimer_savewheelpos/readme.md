SCRIPT BY:
KotzKatze

Thanks for downloading my Script :)
now if you angel you wheels to the left or right and exit the vehicle your wheels will save like that
if you have an engine on / off script it even saves their position even if the engine is on!